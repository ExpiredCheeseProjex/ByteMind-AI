import re
import random
import math
import datetime

# -----------------------------
# AI NAME
# -----------------------------
AI_NAME = "ByteMind AI"

# -----------------------------
# RESPONSE POOLS
# -----------------------------
responses = {
    "greeting": [
        "Hello!", "Hey there!", "Hi! How's it going?", "Yo! 👋", "Hey friend!"
    ],
    "feeling": [
        "I'm doing great, thanks for asking!", "Just chilling in your circuits 😎",
        "Better now that you're here.", "Feeling lively today!"
    ],
    "goodbye": [
        "Goodbye!", "See you later!", "Take care! 👋", "Catch you later!"
    ],
    "thanks": [
        "You're welcome!", "No problem!", "Anytime!", "Glad I could help!"
    ],
    "jokes": [
        "Why did the computer show up at work late? It had a hard drive! 😂",
        "Why do programmers prefer dark mode? Because light attracts bugs! 🐛",
        "I told my computer I needed a break, it said: 'No problem, I'll go sleep.' 😴"
    ],
    "default": [
        "Hmm, interesting...", "Tell me more!", "I’m not sure about that, but I’m listening.",
        "That's cool! Can you explain more?", "Wow, I didn't know that!"
    ]
}

# -----------------------------
# IN-MEMORY STORAGE (reset every run)
# -----------------------------
session = {
    "name": None,
    "conversation_history": [],
    "facts": []
}

# -----------------------------
# UTILITY FUNCTIONS
# -----------------------------
def add_to_history(user_input, bot_response):
    session["conversation_history"].append({
        "timestamp": str(datetime.datetime.now()),
        "user": user_input,
        "bot": bot_response
    })
    # Keep only last 50 messages in memory
    session["conversation_history"] = session["conversation_history"][-50:]

def safe_eval(expr):
    """Evaluate math expressions safely."""
    try:
        allowed_names = {k: getattr(math, k) for k in dir(math) if not k.startswith("__")}
        allowed_names.update({"abs": abs, "round": round})
        code = compile(expr, "<string>", "eval")
        for name in code.co_names:
            if name not in allowed_names:
                return "I can only compute safe math expressions."
        return eval(code, {"__builtins__": {}}, allowed_names)
    except Exception as e:
        return f"Error evaluating math: {e}"

def get_user_name():
    return session["name"] if session.get("name") else "friend"

# -----------------------------
# CHATBOT FUNCTIONS
# -----------------------------
def set_name(name):
    session["name"] = name.title()
    return f"Nice to meet you, {session['name']}!"

def remember_fact(fact):
    session["facts"].append(fact)
    return f"Got it! I'll remember that you {fact} (for this session)."

def recall_memory():
    facts = session.get("facts", [])
    name_info = f"Your name is {session['name']}." if session.get("name") else ""
    if facts:
        return name_info + " You told me: " + "; ".join(facts)
    elif name_info:
        return name_info
    else:
        return "I don't remember anything yet."

def tell_joke():
    return random.choice(responses["jokes"])

def greet_user():
    if session.get("name"):
        return f"{random.choice(responses['greeting'])} {session['name']}!"
    else:
        return random.choice(responses["greeting"])

# -----------------------------
# PATTERN MATCHING
# -----------------------------
patterns = {
    r"my name is (\w+)": lambda match: set_name(match.group(1)),
    r"remember that (.+)": lambda match: remember_fact(match.group(1)),
    r"what do you remember": lambda _: recall_memory(),
    r"joke me": lambda _: tell_joke(),
    r"(how are you|how's it going)": lambda _: random.choice(responses["feeling"]),
    r"(hello|hi|hey)": lambda _: greet_user(),
    r"(bye|goodbye|see ya)": lambda _: random.choice(responses["goodbye"]),
    r"(thanks|thank you)": lambda _: random.choice(responses["thanks"]),
    r"(time|what time is it)": lambda _: f"The current time is {datetime.datetime.now().strftime('%H:%M:%S')}"
}

# -----------------------------
# RESPONSE FUNCTION
# -----------------------------
def chatbot_response(user_input):
    user_input_lower = user_input.lower()

    # --- Math evaluation ---
    math_keywords = set("0123456789+-*/()., ")
    if any(c in math_keywords for c in user_input_lower) and re.search(r"\d", user_input_lower):
        math_result = safe_eval(user_input_lower)
        if isinstance(math_result, (int, float)):
            add_to_history(user_input, f"The answer is: {math_result}")
            return f"The answer is: {math_result}"
        elif isinstance(math_result, str) and math_result.startswith("Error"):
            return math_result

    # --- Pattern matching ---
    for pattern, func in patterns.items():
        match = re.search(pattern, user_input_lower)
        if match:
            response = func(match) if match.groups() else func(None)
            add_to_history(user_input, response)
            return response

    # --- Context-aware fallback using last messages ---
    context_ref = session["conversation_history"][-5:]  # last 5 messages
    if context_ref:
        response = f"I remember we talked about '{context_ref[-1]['user']}', that's interesting!"
        add_to_history(user_input, response)
        return response

    # --- Default fallback ---
    response = random.choice(responses["default"])
    add_to_history(user_input, response)
    return response

# -----------------------------
# MAIN LOOP
# -----------------------------
def main():
    print(f"{AI_NAME} is online! Type 'bye' to quit.")
    while True:
        user_input = input("You: ")
        if re.search(r"bye|goodbye", user_input.lower()):
            print(f"{AI_NAME}: {random.choice(responses['goodbye'])}")
            break
        response = chatbot_response(user_input)
        print(f"{AI_NAME}: {response}")

# -----------------------------
# ENTRY POINT
# -----------------------------
if __name__ == "__main__":
    main()
