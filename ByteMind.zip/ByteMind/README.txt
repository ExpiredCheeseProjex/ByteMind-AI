# ByteMind AI (Memory-Free Version)

THIS IS A WORK-IN-PROGRESS AI.  
Do not expect too much yet, but it is usable for

- Simple conversation
- Math solving
- Jokes
- Time queries

How to run
1. Install Python 3.10+
2. Run `python ByteMindAI.py` in your terminal
3. Chat with the AI!

Note: This AI does not save memory between sessions.
